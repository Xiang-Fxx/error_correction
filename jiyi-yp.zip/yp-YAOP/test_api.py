"""
Automated test suite for the SSP-MMC Memory Backend.

Structure
---------
PART A  Unit tests  — pure Python, no server required
PART B  Integration — starts the real server, fires HTTP requests, tears down

Run:  python test_api.py
"""

import asyncio
import datetime
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error

# ── helpers ─────────────────────────────────────────────────────────────────

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SRC_DIR      = os.path.join(PROJECT_ROOT, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

BASE_URL   = "http://127.0.0.1:8000"
PASS = "[PASS]"
FAIL = "[FAIL]"

_results = []

def record(label: str, passed: bool, detail: str = ""):
    status = PASS if passed else FAIL
    line   = f"  {status}  {label}"
    if detail:
        line += f"\n         {detail}"
    print(line)
    _results.append((label, passed))

def http(method: str, path: str, body=None):
    """Thin wrapper around urllib — no requests dependency needed."""
    url  = BASE_URL + path
    data = json.dumps(body).encode() if body is not None else None
    req  = urllib.request.Request(
        url, data=data, method=method,
        headers={"Content-Type": "application/json"} if data else {},
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return resp.status, json.loads(resp.read())

def http_get(path):
    return http("GET", path)

def http_post(path, body=None):
    return http("POST", path, body)


# ════════════════════════════════════════════════════════════════════════════
# PART A — Unit tests (no server)
# ════════════════════════════════════════════════════════════════════════════

def test_A1_schema_today_review_item():
    """TodayReviewItem has p_recall and is_overdue fields."""
    from schemas import TodayReviewItem, CardRead
    import inspect
    fields = TodayReviewItem.model_fields
    has_p   = "p_recall"   in fields
    has_ov  = "is_overdue" in fields
    record("A1  TodayReviewItem有p_recall字段",   has_p)
    record("A2  TodayReviewItem有is_overdue字段",  has_ov)

    # Construct one — must not raise
    now = datetime.datetime.now(datetime.timezone.utc)
    try:
        item = TodayReviewItem(
            id=1, content="测试题目", difficulty=5, half_life=2.0,
            last_review=now, next_review=now, review_count=0,
            status="active", p_recall=0.72, is_overdue=False,
        )
        record("A3  TodayReviewItem可正常实例化", True, f"p_recall={item.p_recall}")
    except Exception as e:
        record("A3  TodayReviewItem可正常实例化", False, str(e))


def test_A2_memorystate_field_names():
    """MemoryState uses d= and h=, not difficulty= / half_life=."""
    from dhp_model import MemoryState
    try:
        s = MemoryState(d=5, h=2.0)
        record("A4  MemoryState(d=, h=)正确创建", True, f"d={s.d}, h={s.h}")
    except Exception as e:
        record("A4  MemoryState(d=, h=)正确创建", False, str(e))

    # Wrong field names must raise
    try:
        _ = MemoryState(difficulty=5, half_life=2.0)
        record("A5  MemoryState拒绝错误字段名difficulty=", False,
               "应当抛出TypeError但没有")
    except TypeError:
        record("A5  MemoryState拒绝错误字段名difficulty=", True)


def test_A3_timezone_safety_naive():
    """update_card_after_review: naive current_time must NOT crash."""
    from scheduler import update_card_after_review

    # Build a minimal mock Card with naive last_review
    class MockCard:
        difficulty   = 5
        half_life    = 1.0
        review_count = 0
        last_review  = datetime.datetime(2024, 1, 1, 12, 0, 0)   # naive
        next_review  = datetime.datetime(2024, 1, 2, 12, 0, 0)   # naive

    naive_now = datetime.datetime(2024, 1, 2, 12, 0, 0)  # naive input
    try:
        result = asyncio.run(
            update_card_after_review(MockCard(), True, naive_now)
        )
        ok = isinstance(result.get("p_value"), float)
        record("A6  naive datetime输入不崩溃", ok,
               f"p_value={result.get('p_value'):.4f}")
    except TypeError as e:
        record("A6  naive datetime输入不崩溃", False, f"TypeError: {e}")
    except Exception as e:
        record("A6  naive datetime输入不崩溃", False, f"{type(e).__name__}: {e}")


def test_A4_timezone_safety_aware():
    """update_card_after_review: aware current_time + naive last_review."""
    from scheduler import update_card_after_review

    class MockCard:
        difficulty   = 7
        half_life    = 3.0
        review_count = 2
        last_review  = datetime.datetime(2024, 1, 1, 0, 0, 0)    # naive
        next_review  = datetime.datetime(2024, 1, 5, 0, 0, 0)

    aware_now = datetime.datetime(2024, 1, 3, 0, 0, 0,
                                  tzinfo=datetime.timezone.utc)  # aware
    try:
        result = asyncio.run(
            update_card_after_review(MockCard(), False, aware_now)
        )
        ok = isinstance(result.get("delta_t"), float) and result["delta_t"] > 0
        record("A7  aware + naive混用不崩溃", ok,
               f"delta_t={result.get('delta_t'):.4f}d")
    except TypeError as e:
        record("A7  aware + naive混用不崩溃", False, f"TypeError: {e}")
    except Exception as e:
        record("A7  aware + naive混用不崩溃", False, f"{type(e).__name__}: {e}")


def test_A5_timezone_safety_both_aware():
    """update_card_after_review: both datetimes aware."""
    from scheduler import update_card_after_review
    UTC = datetime.timezone.utc

    class MockCard:
        difficulty   = 3
        half_life    = 5.0
        review_count = 1
        last_review  = datetime.datetime(2024, 2, 1, 0, 0, 0, tzinfo=UTC)
        next_review  = datetime.datetime(2024, 2, 10, 0, 0, 0, tzinfo=UTC)

    aware_now = datetime.datetime(2024, 2, 3, 0, 0, 0, tzinfo=UTC)
    try:
        result = asyncio.run(
            update_card_after_review(MockCard(), True, aware_now)
        )
        ok = 0 < result.get("p_value", 0) <= 1
        record("A8  两者都是aware不崩溃", ok,
               f"p_value={result.get('p_value'):.4f}, new_h={result.get('new_h'):.2f}")
    except Exception as e:
        record("A8  两者都是aware不崩溃", False, f"{type(e).__name__}: {e}")


def test_A6_dhp_round_trip():
    """Full DHP: success raises H, failure lowers H."""
    from dhp_model import MemoryState
    from state_transitions import apply_review

    s = MemoryState(d=5, h=2.0)
    after_success, p_s = apply_review(s, 1.0, 1)
    after_failure, p_f = apply_review(s, 1.0, 0)

    record("A9  成功后H增加", after_success.h > s.h,
           f"H: {s.h:.2f} -> {after_success.h:.2f}")
    record("A10 失败后H减少", after_failure.h < s.h,
           f"H: {s.h:.2f} -> {after_failure.h:.2f}")
    record("A11 recall概率在(0,1]范围内",
           0 < p_s <= 1 and 0 < p_f <= 1,
           f"p_success={p_s:.3f}, p_failure={p_f:.3f}")


# ════════════════════════════════════════════════════════════════════════════
# PART B — Integration tests (real HTTP)
# ════════════════════════════════════════════════════════════════════════════

_server_proc = None

def start_server():
    global _server_proc
    db_path = os.path.join(SRC_DIR, "ssp_mmc.db")
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"  (deleted old DB: {db_path})")

    _server_proc = subprocess.Popen(
        [sys.executable, "main.py"],
        cwd=SRC_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    # Poll until server responds or timeout
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"{BASE_URL}/health", timeout=1)
            print("  Server ready.")
            return True
        except Exception:
            time.sleep(0.4)
    # Dump stderr to help debug
    _server_proc.poll()
    out, err = _server_proc.stdout.read(), _server_proc.stderr.read()
    print("  [SERVER STDOUT]", out.decode(errors="replace")[:800])
    print("  [SERVER STDERR]", err.decode(errors="replace")[:800])
    return False


def stop_server():
    global _server_proc
    if _server_proc:
        _server_proc.terminate()
        try:
            _server_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _server_proc.kill()
        _server_proc = None


def test_B1_health():
    try:
        status, body = http_get("/health")
        ok = status == 200 and body.get("status") == "operational"
        record("B1  GET /health  返回200+operational", ok, str(body))
    except Exception as e:
        record("B1  GET /health  返回200+operational", False, str(e))


def test_B2_create_card():
    """POST /cards/ — creates a card due immediately (next_review = now)."""
    try:
        status, body = http_post("/cards/", {
            "content": "自动化测试题目 — 2+2=?",
            "difficulty": 4,
            "half_life": 1.0,
        })
        ok = status == 201 and "id" in body and body.get("status") == "active"
        record("B2  POST /cards/ 返回201+status=active", ok, f"id={body.get('id')}")
        return body.get("id")
    except Exception as e:
        record("B2  POST /cards/ 返回201+status=active", False, str(e))
        return None


def test_B3_today_review(card_id):
    """GET /api/review/today — must include p_recall and is_overdue."""
    try:
        status, body = http_get("/api/review/today")
        ok_status = status == 200
        ok_list   = isinstance(body, list)
        record("B3  GET /api/review/today 返回200+array", ok_status and ok_list,
               f"共{len(body)}条")

        # Find our test card in the result
        card = next((c for c in body if c.get("id") == card_id), None)
        if card is None and body:
            card = body[0]

        if card:
            has_p  = "p_recall"   in card
            has_ov = "is_overdue" in card
            p_val  = card.get("p_recall", -1)
            ok_p   = has_p and isinstance(p_val, (int, float)) and 0 <= p_val <= 1
            record("B4  响应包含p_recall字段(0~1)", ok_p,
                   f"p_recall={p_val}")
            record("B5  响应包含is_overdue字段(bool)", has_ov,
                   f"is_overdue={card.get('is_overdue')}")
            record("B6  status字段为active", card.get("status") == "active",
                   f"status={card.get('status')}")
        else:
            record("B4  响应包含p_recall字段(0~1)", False,
                   "列表为空，卡片未出现在今日复习中")
            record("B5  响应包含is_overdue字段(bool)", False, "")
            record("B6  status字段为active", False, "")
    except Exception as e:
        record("B3  GET /api/review/today 返回200+array", False, str(e))
        record("B4  响应包含p_recall字段", False, "")
        record("B5  响应包含is_overdue字段", False, "")
        record("B6  status字段为active", False, "")


def test_B4_review_execute(card_id):
    """POST /review/execute/ — triggers DHP, returns new_h, next_review."""
    try:
        now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
        status, body = http_post("/review/execute/", {
            "card_id": card_id,
            "recalled": True,
            "review_time": now_iso,
        })
        ok = status == 200 and "new_h" in body and "next_review" in body
        record("B7  POST /review/execute/ DHP触发成功", ok,
               f"new_h={body.get('new_h'):.3f}, p_value={body.get('p_value'):.4f}"
               if ok else str(body))
    except Exception as e:
        record("B7  POST /review/execute/ DHP触发成功", False, str(e))


def test_B5_master_card(card_id):
    """POST /api/review/{id}/master — marks card as mastered."""
    try:
        status, body = http_post(f"/api/review/{card_id}/master")
        ok = status == 200 and body.get("status") == "mastered"
        record("B8  POST /api/review/{id}/master 标记为mastered", ok,
               f"status={body.get('status')}")
    except Exception as e:
        record("B8  POST /api/review/{id}/master 标记为mastered", False, str(e))


def test_B6_mastered_excluded(card_id):
    """Mastered card must NOT appear in /api/review/today or /review/next/."""
    try:
        _, today_body  = http_get("/api/review/today")
        _, next_body   = http_get("/review/next/")
        in_today = any(c.get("id") == card_id for c in today_body)
        in_next  = any(c.get("id") == card_id for c in next_body)
        record("B9  已掌握卡片不出现在/api/review/today", not in_today)
        record("B10 已掌握卡片不出现在/review/next/",     not in_next)
    except Exception as e:
        record("B9  已掌握卡片不出现在/api/review/today", False, str(e))
        record("B10 已掌握卡片不出现在/review/next/",     False, str(e))


def test_B7_review_page_served():
    """GET /review — must return HTML page (200)."""
    try:
        req = urllib.request.Request(f"{BASE_URL}/review")
        with urllib.request.urlopen(req, timeout=5) as resp:
            html = resp.read(200).decode(errors="replace")
        ok = "今日复习" in html
        record("B11 GET /review 返回包含'今日复习'的HTML", ok,
               html[:80].strip())
    except Exception as e:
        record("B11 GET /review 返回包含'今日复习'的HTML", False, str(e))


def test_B8_404_on_bad_card():
    """master / execute on non-existent card must return 404."""
    try:
        req = urllib.request.Request(
            f"{BASE_URL}/api/review/999999/master",
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            urllib.request.urlopen(req, timeout=5)
            record("B12 不存在的卡片返回404", False, "期望404但返回了2xx")
        except urllib.error.HTTPError as e:
            record("B12 不存在的卡片返回404", e.code == 404,
                   f"HTTP {e.code}")
    except Exception as e:
        record("B12 不存在的卡片返回404", False, str(e))


# ════════════════════════════════════════════════════════════════════════════
# Runner
# ════════════════════════════════════════════════════════════════════════════

def run_unit_tests():
    print("\n" + "═"*58)
    print("  PART A — 单元测试 (无需服务器)")
    print("═"*58)
    test_A1_schema_today_review_item()
    test_A2_memorystate_field_names()
    test_A3_timezone_safety_naive()
    test_A4_timezone_safety_aware()
    test_A5_timezone_safety_both_aware()
    test_A6_dhp_round_trip()


def run_integration_tests():
    print("\n" + "═"*58)
    print("  PART B — 集成测试 (启动真实服务器)")
    print("═"*58)
    print("  正在启动 FastAPI 服务器…")
    if not start_server():
        record("SERVER_START", False, "服务器15秒内未就绪，跳过所有集成测试")
        return

    try:
        test_B1_health()
        card_id = test_B2_create_card()
        if card_id:
            test_B3_today_review(card_id)
            test_B4_review_execute(card_id)
            test_B5_master_card(card_id)
            test_B6_mastered_excluded(card_id)
        test_B7_review_page_served()
        test_B8_404_on_bad_card()
    finally:
        stop_server()
        print("  服务器已关闭。")


def print_summary():
    print("\n" + "═"*58)
    print("  测试结果汇总")
    print("═"*58)
    passed = sum(1 for _, ok in _results if ok)
    total  = len(_results)
    for label, ok in _results:
        print(f"  {'OK' if ok else 'NG'}  {label}")
    print()
    print(f"  结果: {passed}/{total} 通过", end="  ")
    if passed == total:
        print("-- ALL PASSED")
    else:
        failed = [l for l, ok in _results if not ok]
        print(f"-- {len(failed)} FAILED")
    print("═"*58)
    return passed == total


if __name__ == "__main__":
    run_unit_tests()
    run_integration_tests()
    all_ok = print_summary()
    sys.exit(0 if all_ok else 1)
