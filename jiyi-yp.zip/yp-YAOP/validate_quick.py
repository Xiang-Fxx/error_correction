"""Quick pure-Python validation — no numpy/scipy needed."""
import sys, math
sys.path.insert(0, 'src')

from dhp_model import (
    MemoryState, default_halflife, recall_prob_vec,
    clamp_halflife, H_MIN
)

# Default parameters (pre-fit)
THETA = dict(
    theta1=0.60, theta2=-0.10, theta3=0.50, theta4=-0.15,
    theta5=-0.30, theta6=-0.10,
)

def halflife_success(h, d, p):
    lf = (THETA['theta1']
          + THETA['theta2'] * math.log(max(h, H_MIN))
          + THETA['theta3'] * (1.0 - p)
          + THETA['theta4'] * math.log(max(d, 1)))
    return clamp_halflife(h * math.exp(lf))

def halflife_failure(h, d):
    lf = THETA['theta5'] + THETA['theta6'] * math.log(max(d, 1))
    return clamp_halflife(h * math.exp(lf))

# ── TEST A: Consecutive successes ─────────────────────────────────────
print("=" * 58)
print("  TEST A: H growth after 3 consecutive successes (D=5)")
print("=" * 58)

h     = default_halflife(5)
last  = 0.0
h_history = [h]
print(f"  Init : H = {h:.4f} days")

for i in range(1, 7):
    gap = -h * math.log2(0.90)
    p   = recall_prob_vec(gap, h)
    h_new = halflife_success(h, 5, p)
    ratio = h_new / h
    print(f"  Rev {i}: Δt={gap:6.2f}d  P={p:.3f}  "
          f"H: {h:.4f} → {h_new:.4f}  (×{ratio:.3f})")
    h = h_new
    h_history.append(h)
    last += gap

ratios = [h_history[i+1] / h_history[i] for i in range(len(h_history)-1)]
print(f"\n  H values : {[round(v,3) for v in h_history]}")
print(f"  Ratios   : {[round(r,3) for r in ratios]}")
print(f"  All > 1? : {all(r > 1.0 for r in ratios)}")

# ── TEST B: Failure penalty ────────────────────────────────────────────
print()
print("=" * 58)
print("  TEST B: H drop after failure — D=1 vs D=10 (H_before=5.0)")
print("=" * 58)

h0 = 5.0
drops = []
print(f"  {'D':>3}  {'H_after':>9}  {'Drop':>8}  {'Drop%':>7}")
print(f"  {'-'*3}  {'-'*9}  {'-'*8}  {'-'*7}")

for d in range(1, 11):
    h_new = halflife_failure(h0, d)
    drop  = h0 - h_new
    drops.append(drop)
    print(f"  {d:>3}  {h_new:>9.4f}  {drop:>8.4f}  {drop/h0*100:>6.1f}%")

monotone = all(drops[i] <= drops[i+1] for i in range(len(drops)-1))
print(f"\n  Drop strictly increases with D: {monotone}")
print(f"  ✓ PASS" if monotone else "  ✗ FAIL")
print("=" * 58)
