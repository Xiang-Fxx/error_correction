"""
DHP Model — Core Memory Physics Engine
=======================================
Based on KDD 2022 SSP-MMC paper.

State Space:
  D  — Difficulty:         integer in [1, 10]
  H  — Half-life (days):   H > 0, measures memory strength
  P  — Recall probability: P = 2^(−Δt / H)  ∈ (0, 1]

Key insight: H encodes *how long* a memory persists before the recall
probability drops to 50%.  A higher H means slower forgetting.

This module defines the MemoryState dataclass and all helper functions
that operate on raw (D, H, P) values, keeping them fully decoupled from
the scheduling / optimisation logic that comes later.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

D_MIN: int   = 1         # Minimum difficulty
D_MAX: int   = 10        # Maximum difficulty
H_MIN: float = 0.1       # Minimum half-life in days (≈ 2.4 hours)
H_MAX: float = 3650.0    # Maximum half-life in days (≈ 10 years)
P_THRESHOLD: float = 0.9 # "Mastered" threshold — P ≥ this at scheduled review


# ---------------------------------------------------------------------------
# State dataclass
# ---------------------------------------------------------------------------

@dataclass
class MemoryState:
    """
    A single card's memory state at a given moment.

    Attributes
    ----------
    d : int
        Difficulty level ∈ [1, 10].  1 = very easy, 10 = very hard.
    h : float
        Half-life in days.  Initialised from ``default_halflife(d)``.
    last_review : float
        Timestamp (days since epoch) of the most recent review.
    review_count : int
        Total number of times the card has been reviewed.
    """
    d: int
    h: float
    last_review: float = 0.0
    review_count: int  = 0

    # ------------------------------------------------------------------
    def __post_init__(self) -> None:
        self.d = int(max(D_MIN, min(D_MAX, self.d)))
        self.h = float(max(H_MIN, min(H_MAX, self.h)))

    # ------------------------------------------------------------------
    # Formula (Paper Eq. 6)
    # P = 2^(−Δt / H)
    # ------------------------------------------------------------------
    def recall_prob(self, current_time: float) -> float:
        """
        Compute the recall probability at ``current_time`` (days).

        P = 2^(−Δt / H)

        Parameters
        ----------
        current_time : float
            The day at which we want to evaluate retrieval probability.

        Returns
        -------
        float
            P ∈ (0, 1].  Returns 1.0 if Δt ≤ 0 (just reviewed).
        """
        delta_t = current_time - self.last_review
        if delta_t <= 0.0:
            return 1.0
        return 2.0 ** (-delta_t / self.h)

    # ------------------------------------------------------------------
    def optimal_interval(self, target_p: float = P_THRESHOLD) -> float:
        """
        Return Δt such that P(Δt) = target_p.

        Δt* = −H · log2(target_p)

        Parameters
        ----------
        target_p : float
            Desired recall probability at review time, e.g. 0.9.

        Returns
        -------
        float
            Optimal interval in days.
        """
        if target_p <= 0.0 or target_p >= 1.0:
            raise ValueError(f"target_p must be in (0, 1), got {target_p}")
        return -self.h * math.log2(target_p)

    # ------------------------------------------------------------------
    def __repr__(self) -> str:
        return (
            f"MemoryState(D={self.d}, H={self.h:.3f}d, "
            f"reviews={self.review_count})"
        )


# ---------------------------------------------------------------------------
# Helper: difficulty → initial half-life
# ---------------------------------------------------------------------------

def default_halflife(d: int) -> float:
    """
    Heuristic initial half-life for a brand-new card of difficulty d.

    Harder cards (high d) start with a shorter half-life — they are
    forgotten more quickly from the first encounter.

    Formula: H_0 = H_base / d^0.5
    where H_base = 1.0 day for an average-difficulty card (d=5).

    Returns
    -------
    float
        Initial half-life in days, clamped to [H_MIN, H_MAX].
    """
    h_base = 1.0
    h0 = h_base / math.sqrt(d / 5.0)
    return float(max(H_MIN, min(H_MAX, h0)))


# ---------------------------------------------------------------------------
# Vectorised helpers (used by the data generator)
# ---------------------------------------------------------------------------

def recall_prob_vec(delta_t: float, h: float) -> float:
    """Stateless recall probability for a given (Δt, H) pair."""
    if delta_t <= 0.0:
        return 1.0
    return 2.0 ** (-delta_t / h)


def clamp_halflife(h: float) -> float:
    """Clamp H to [H_MIN, H_MAX]."""
    return float(max(H_MIN, min(H_MAX, h)))


def clamp_difficulty(d: int) -> int:
    """Clamp D to [D_MIN, D_MAX]."""
    return int(max(D_MIN, min(D_MAX, d)))
