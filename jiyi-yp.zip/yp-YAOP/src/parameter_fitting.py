"""
Parameter Fitting — Recover θ from Review Logs
================================================
Fits the six θ parameters using pure-Python Linear Least Squares
via the Normal Equations.  No numpy, pandas, or scipy required.

Key insight: on the log scale, Eqs. (7) and (8) are LINEAR in θ:

    SUCCESS — Eq. (7):
        y = ln(H_after) − ln(H_before)
          = θ₁·1 + θ₂·ln(H) + θ₃·(1−P) + θ₄·ln(D)
        → standard 4-feature linear regression, zero intercept form

    FAILURE — Eq. (8):
        y = ln(H_after) − ln(H_before)
          = θ₅·1 + θ₆·ln(D)
        → standard 2-feature linear regression, zero intercept form

Both branches are solved analytically via (XᵀX)⁻¹Xᵀy,
implemented here in ~100 lines of pure Python.
This runs in milliseconds even on 200k rows.
"""

from __future__ import annotations

import logging
import math
from typing import Dict, List, Tuple

from dhp_model import H_MIN

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pure-Python matrix helpers
# ---------------------------------------------------------------------------

def _mat_mul(A: List[List[float]], B: List[List[float]]) -> List[List[float]]:
    m, k, n = len(A), len(B), len(B[0])
    C = [[0.0] * n for _ in range(m)]
    for i in range(m):
        for j in range(n):
            C[i][j] = sum(A[i][p] * B[p][j] for p in range(k))
    return C

def _mat_inv(M: List[List[float]]) -> List[List[float]]:
    n = len(M)
    A = [row[:] + [1.0 if i == j else 0.0 for j in range(n)]
         for i, row in enumerate(M)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(A[r][col]))
        A[col], A[pivot] = A[pivot], A[col]
        diag = A[col][col]
        if abs(diag) < 1e-14: raise ValueError("Singular matrix")
        A[col] = [x / diag for x in A[col]]
        for row in range(n):
            if row != col:
                factor = A[row][col]
                A[row] = [A[row][j] - factor * A[col][j] for j in range(2 * n)]
    return [row[n:] for row in A]

def _ols(X_rows: List[List[float]], y: List[float]) -> List[float]:
    n_feat = len(X_rows[0])
    XtX = [[0.0] * n_feat for _ in range(n_feat)]
    Xty = [0.0] * n_feat
    for row, yi in zip(X_rows, y):
        for i in range(n_feat):
            for j in range(n_feat): XtX[i][j] += row[i] * row[j]
            Xty[i] += row[i] * yi
    inv = _mat_inv(XtX)
    return [sum(inv[i][j] * Xty[j] for j in range(n_feat)) for i in range(n_feat)]


# ---------------------------------------------------------------------------
# Build design matrices
# ---------------------------------------------------------------------------

def _build_success_Xy(rows: List[dict]) -> Tuple[List[List[float]], List[float]]:
    X, y = [], []
    for r in rows:
        lh, ld = math.log(max(r["h_before"], H_MIN)), math.log(max(r["difficulty"], 1))
        omp = 1.0 - max(1e-9, min(1.0, r["recall_prob"]))
        X.append([1.0, lh, omp, ld])
        y.append(math.log(max(r["h_after"], H_MIN)) - lh)
    return X, y

def _build_failure_Xy(rows: List[dict]) -> Tuple[List[List[float]], List[float]]:
    X, y = [], []
    for r in rows:
        lh, ld = math.log(max(r["h_before"], H_MIN)), math.log(max(r["difficulty"], 1))
        X.append([1.0, ld])
        y.append(math.log(max(r["h_after"], H_MIN)) - lh)
    return X, y

def _rmse_linear(X_rows, y, theta_vec):
    sse = sum((yi - sum(xj * tj for xj, tj in zip(row, theta_vec))) ** 2 for row, yi in zip(X_rows, y))
    return math.sqrt(sse / max(len(y), 1))


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

def fit_parameters(records: List[dict], verbose: bool = True) -> Dict[str, float]:
    success_rows, failure_rows = [r for r in records if r["outcome"] == 1], [r for r in records if r["outcome"] == 0]
    if verbose: logger.info("  Fitting on %s success, %s failure rows...", f"{len(success_rows):,}", f"{len(failure_rows):,}")
    Xs, ys = _build_success_Xy(success_rows)
    ts = _ols(Xs, ys)
    Xf, yf = _build_failure_Xy(failure_rows)
    tf = _ols(Xf, yf)
    theta = {"theta1": ts[0], "theta2": ts[1], "theta3": ts[2], "theta4": ts[3], "theta5": tf[0], "theta6": tf[1]}
    if verbose:
        logger.info("\n" + "="*60 + "\n  Parameter Fitting Report (Closed OLS)\n" + "="*60)
        for i, (k, l) in enumerate([("theta1","θ₁"),("theta2","θ₂"),("theta3","θ₃"),("theta4","θ₄")]): logger.info(f"    {l} = {theta[k]:+.4f}")
        logger.info(f"    RMSE = {_rmse_linear(Xs, ys, ts):.4f}")
        for i, (k, l) in enumerate([("theta5","θ₅"),("theta6","θ₆")]): logger.info(f"    {l} = {theta[k]:+.4f}")
        logger.info(f"    RMSE = {_rmse_linear(Xf, yf, tf):.4f}")
        logger.info("="*60)
    return theta

def evaluate_fit(records: List[dict], theta: Dict[str, float], verbose: bool = True) -> Dict[str, float]:
    success_rows, failure_rows = [r for r in records if r["outcome"] == 1], [r for r in records if r["outcome"] == 0]
    Xs, ys = _build_success_Xy(success_rows)
    Xf, yf = _build_failure_Xy(failure_rows)
    ts, tf = [theta[k] for k in ["theta1","theta2","theta3","theta4"]], [theta[k] for k in ["theta5","theta6"]]
    rs, rf = _rmse_linear(Xs, ys, ts), _rmse_linear(Xf, yf, tf)
    ro = math.sqrt((rs**2 + rf**2)/2)
    if verbose: logger.info("  Eval RMSE: S=%.4f, F=%.4f, Overall=%.4f", rs, rf, ro)
    return {"rmse_success": rs, "rmse_failure": rf, "rmse_overall": ro}
