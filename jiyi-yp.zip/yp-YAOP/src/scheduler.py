import math
import datetime
from typing import Optional, List, Dict, Any

from dhp_model import MemoryState, recall_prob_vec
from state_transitions import apply_review
from models import Card

# --- Senior Architecture Constants ---

# The "Necessary Difficulty" sweet spot (P ≈ 0.6)
# According to the KDD paper, reviewing at this probability maximizes memory consolidation efficiency.
TARGET_P = 0.618  # Using the golden ratio for a slightly more "elegant" sweet spot

# Gaussian dispersion for priority weighting
# Larger values make the priority "flatter" around the peak.
P_DISPERSION_SIGMA = 0.15

# Urgency factor for overdue cards (P < 0.618)
URGENCY_SLOPE = 0.5

def calculate_next_review(h: float, p_target: float = TARGET_P) -> datetime.datetime:
    """
    Solves for delta_t given target recall probability P.
    Formula: delta_t = -H * log2(P)
    """
    # Defensive math: ensure H is sane and P is in (0, 1)
    h_safe = max(0.001, h)
    p_safe = max(0.01, min(0.99, p_target))
    
    delta_t_days = -h_safe * math.log2(p_safe)
    
    # Use UTC to prevent timezone drift in the database
    now = datetime.datetime.now(datetime.timezone.utc)
    return now + datetime.timedelta(days=delta_t_days)

def calculate_priority_score(card: Card) -> float:
    """
    Advanced Scheduler Weighting based on Information Gain / Necessary Difficulty.
    
    Logic:
    1.  Max priority occurs at P ≈ 0.618 (The Optimal Recall Point).
    2.  If P > 0.618: The card is "too easy" to review. Priority drops off 
        Gaussian-style (less benefit).
    3.  If P < 0.618: The card is "overdue". Priority increases linearly 
        because forgetfulness risk is escalating.
    
    Returns a float: Higher = More Urgent / Higher Priority.
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    # Guard card.last_review against naive datetimes returned by SQLite
    last = card.last_review
    if last.tzinfo is None:
        last = last.replace(tzinfo=datetime.timezone.utc)
    delta_t_seconds = max(0, (now - last).total_seconds())
    delta_t_days = delta_t_seconds / (3600 * 24)
    
    # Get current Estimated Recall Probability
    p = recall_prob_vec(delta_t_days, card.half_life)
    
    # --- Weight Components ---
    
    # A. The "Sweet Spot" Gaussian peak (Centered at 0.618)
    # This represents the optimal efficiency for neural consolidation.
    sweet_spot_weight = math.exp(-((p - TARGET_P) ** 2) / (2 * (P_DISPERSION_SIGMA ** 2)))
    
    # B. The "Urgency" linear term
    # If p < sweet spot, it's overdue. We scale priority up.
    urgency_offset = 0.0
    if p < TARGET_P:
        urgency_offset = (TARGET_P - p) * URGENCY_SLOPE
    
    # Combine: Peak + Overdue Growth
    priority = sweet_spot_weight + urgency_offset
    
    # C. "Freshness" suppression (Architectural best practice)
    # Don't let a card show up twice in the same minute if the user failed repeatedly.
    if delta_t_seconds < 60:
        priority *= 0.1
        
    return priority

async def update_card_after_review(card: Card, recalled: bool, current_time: datetime.datetime) -> Dict[str, Any]:
    """
    The State Transformer.
    Bridges the physical mathematical engine (V1) with the persistent entities (V2).
    """
    # Ensure both datetimes are timezone-aware before subtraction.
    # SQLite returns aware datetimes (UTC); guard against naive inputs.
    UTC = datetime.timezone.utc
    if current_time.tzinfo is None:
        current_time = current_time.replace(tzinfo=UTC)
    last = card.last_review
    if last.tzinfo is None:
        last = last.replace(tzinfo=UTC)

    delta_t = (current_time - last).total_seconds() / (3600 * 24)

    # 1. Physical Transition Logic (Formulas 7 & 8 from spec)
    # NOTE: MemoryState uses field names d= and h=, not difficulty= and half_life=
    state = MemoryState(d=card.difficulty, h=card.half_life)
    new_state, p_at_review = apply_review(state, delta_t, int(recalled))

    # 2. Update persistent state
    card.difficulty = new_state.d
    card.half_life = new_state.h
    card.last_review = current_time
    
    # Rule: Next review is scheduled where P hits the "Sweet Spot" (0.618)
    card.next_review = calculate_next_review(card.half_life, TARGET_P)
    card.review_count += 1
    
    return {
        "p_value": p_at_review,
        "new_h": card.half_life,
        "new_d": card.difficulty,
        "delta_t": delta_t,
        "next_review": card.next_review
    }
