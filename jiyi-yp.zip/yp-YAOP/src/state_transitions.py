"""
State Transition Equations — Paper Formulae (6), (7), (8)
==========================================================
This module is the **heart** of the DHP physical engine.

It implements the three core equations from the KDD 2022 SSP-MMC paper
that govern how memory state (D, H) evolves after each review.

Paper Equations
---------------
Eq. (6)  Recall probability:
    P = 2^(−Δt / H)

Eq. (7)  Half-life update on SUCCESS (r = 1):
    H_new = H · exp( θ₁ + θ₂·ln(H) + θ₃·(1 − P) + θ₄·ln(D) )

    Intuition:
      • Base multiplicative factor from θ₁.
      • θ₂·ln(H): diminishing returns — already-strong memories grow
        proportionally less with each success.
      • θ₃·(1 − P): larger boost when recall was *harder* (lower P, i.e.
        the card was almost forgotten).  This is the "desirable difficulty"
        effect — struggling and succeeding strengthens memory more.
      • θ₄·ln(D): difficulty modulation — harder cards (high D) grow
        their H more slowly on success.

Eq. (8)  Half-life update on FAILURE (r = 0):
    H_new = H · exp( θ₅ + θ₆·ln(D) )

    Intuition:
      • H always shrinks (θ₅ < 0 in fitted parameters).
      • θ₆·ln(D): harder cards (high D) suffer a *greater* H reduction on
        failure — they are harder to recover from a lapse.

Difficulty update (auxiliary, from paper Section 3.2):
    D_new = D + δ_success  (r = 1, small decrease towards easier)
    D_new = D + δ_failure  (r = 0, increase difficulty estimate)
    Clipped to [D_MIN, D_MAX].

Default parameters θ (used before fitting on real data):
    These are reasonable initialisations matching the paper's reported
    ranges; the parameter_fitting module will refine them on your data.
"""

from __future__ import annotations

import math
from typing import Tuple

from dhp_model import (
    MemoryState,
    recall_prob_vec,
    clamp_halflife,
    clamp_difficulty,
    D_MIN, D_MAX, H_MIN,
)


# ---------------------------------------------------------------------------
# Default (pre-fit) parameters
# ---------------------------------------------------------------------------

# θ for success branch — Eq. (7)
DEFAULT_THETA_SUCCESS = {
    "theta1": 0.60,   # base log-growth factor
    "theta2": -0.10,  # diminishing returns on existing H
    "theta3":  0.50,  # bonus for high-difficulty recall (1 - P large)
    "theta4": -0.15,  # harder words grow H less per success
}

# θ for failure branch — Eq. (8)
DEFAULT_THETA_FAILURE = {
    "theta5": -0.30,  # base penalty (always negative)
    "theta6": -0.10,  # harder words are penalised more on failure
}

# Difficulty shift per outcome
DELTA_D_SUCCESS: float = -0.2   # slight ease on success
DELTA_D_FAILURE: float =  0.5   # bigger difficulty bump on failure


# ---------------------------------------------------------------------------
# Eq. (7) — half-life update on success
# ---------------------------------------------------------------------------

def halflife_on_success(
    h: float,
    d: int,
    p: float,
    theta1: float = DEFAULT_THETA_SUCCESS["theta1"],
    theta2: float = DEFAULT_THETA_SUCCESS["theta2"],
    theta3: float = DEFAULT_THETA_SUCCESS["theta3"],
    theta4: float = DEFAULT_THETA_SUCCESS["theta4"],
) -> float:
    """
    Update half-life after a *successful* recall (r = 1).

    H_new = H · exp( θ₁ + θ₂·ln(H) + θ₃·(1 − P) + θ₄·ln(D) )

    Parameters
    ----------
    h      : current half-life in days
    d      : difficulty ∈ [1, 10]
    p      : recall probability at the moment of review (Eq. 6 value)
    theta* : model parameters (fitted or default)

    Returns
    -------
    float  : updated half-life, clamped to [H_MIN, H_MAX]

    Verification
    ------------
    >>> # After 3 consecutive successes starting from H=1.0, D=5
    >>> h = 1.0; d = 5; dt = 1.0
    >>> for _ in range(3):
    ...     p = recall_prob_vec(dt, h)
    ...     h = halflife_on_success(h, d, p)
    ...     dt = h * 0.5          # always review at t = H/2 → P≈0.71
    H should grow roughly exponentially each round.
    """
    log_factor = (
        theta1
        + theta2 * math.log(max(h, H_MIN))
        + theta3 * (1.0 - p)
        + theta4 * math.log(max(d, 1))
    )
    h_new = h * math.exp(log_factor)
    return clamp_halflife(h_new)


# ---------------------------------------------------------------------------
# Eq. (8) — half-life update on failure
# ---------------------------------------------------------------------------

def halflife_on_failure(
    h: float,
    d: int,
    theta5: float = DEFAULT_THETA_FAILURE["theta5"],
    theta6: float = DEFAULT_THETA_FAILURE["theta6"],
) -> float:
    """
    Update half-life after a *failed* recall (r = 0).

    H_new = H · exp( θ₅ + θ₆·ln(D) )

    Parameters
    ----------
    h      : current half-life in days
    d      : difficulty ∈ [1, 10]
    theta* : model parameters

    Returns
    -------
    float  : updated half-life, clamped to [H_MIN, H_MAX]

    Verification
    ------------
    >>> # Hard word (D=9) should lose more H than easy word (D=2)
    >>> h_easy = halflife_on_failure(5.0, d=2)
    >>> h_hard = halflife_on_failure(5.0, d=9)
    >>> assert h_hard < h_easy  # must hold
    """
    log_factor = theta5 + theta6 * math.log(max(d, 1))
    h_new = h * math.exp(log_factor)
    return clamp_halflife(h_new)


# ---------------------------------------------------------------------------
# Difficulty update (auxiliary)
# ---------------------------------------------------------------------------

def difficulty_update(d: int, r: int) -> int:
    """
    Adjust difficulty level based on recall outcome.

    Success → nudge D down (word is proving easier than expected).
    Failure → nudge D up   (word is proving harder than expected).

    The update is small and continuous, then rounded+clamped so D
    remains a valid integer in [D_MIN, D_MAX].

    Parameters
    ----------
    d : current difficulty
    r : recall outcome, 1 = success, 0 = failure

    Returns
    -------
    int : updated difficulty
    """
    if r == 1:
        d_new = d + DELTA_D_SUCCESS
    else:
        d_new = d + DELTA_D_FAILURE
    return clamp_difficulty(round(d_new))


# ---------------------------------------------------------------------------
# Master transition function (combines Eqs 6, 7/8, + D update)
# ---------------------------------------------------------------------------

def apply_review(
    state: MemoryState,
    current_time: float,
    recall_outcome: int,
    theta: dict | None = None,
) -> Tuple[MemoryState, float]:
    """
    Apply a single review event to a MemoryState.

    This is the master function that chains:
      1. Eq. (6)  → compute P at review time
      2. Eq. (7) or (8) → update H based on outcome
      3. Auxiliary → update D based on outcome

    Parameters
    ----------
    state         : current MemoryState before review
    current_time  : day on which the review occurs
    recall_outcome: 1 = recalled correctly, 0 = forgotten
    theta         : optional dict of all 6 θ parameters; uses defaults
                    if None.

    Returns
    -------
    (new_state, p_at_review)
        new_state    : updated MemoryState (immutable-style new object)
        p_at_review  : the recall probability that was observed at review
    """
    if theta is None:
        theta = {}

    # Step 1 — Eq. (6): recall probability
    p = recall_prob_vec(current_time - state.last_review, state.h)

    # Step 2 — Eq. (7) or (8): update H
    if recall_outcome == 1:
        h_new = halflife_on_success(
            h      = state.h,
            d      = state.d,
            p      = p,
            theta1 = theta.get("theta1", DEFAULT_THETA_SUCCESS["theta1"]),
            theta2 = theta.get("theta2", DEFAULT_THETA_SUCCESS["theta2"]),
            theta3 = theta.get("theta3", DEFAULT_THETA_SUCCESS["theta3"]),
            theta4 = theta.get("theta4", DEFAULT_THETA_SUCCESS["theta4"]),
        )
    else:
        h_new = halflife_on_failure(
            h      = state.h,
            d      = state.d,
            theta5 = theta.get("theta5", DEFAULT_THETA_FAILURE["theta5"]),
            theta6 = theta.get("theta6", DEFAULT_THETA_FAILURE["theta6"]),
        )

    # Step 3 — auxiliary: update D
    d_new = difficulty_update(state.d, recall_outcome)

    new_state = MemoryState(
        d           = d_new,
        h           = h_new,
        last_review = current_time,
        review_count= state.review_count + 1,
    )
    return new_state, p


# ---------------------------------------------------------------------------
# Convenience: simulate a sequence of reviews
# ---------------------------------------------------------------------------

def simulate_reviews(
    initial_state: MemoryState,
    outcomes: list[int],
    intervals: list[float],
    theta: dict | None = None,
) -> list[Tuple[MemoryState, float]]:
    """
    Simulate a series of reviews on one card.

    Parameters
    ----------
    initial_state : starting MemoryState
    outcomes      : list of 1/0 recall results, length N
    intervals     : list of inter-review gaps in days, length N
    theta         : optional θ parameter dict

    Returns
    -------
    list of (MemoryState, p_at_review) after each review
    """
    assert len(outcomes) == len(intervals), \
        "outcomes and intervals must have the same length"

    history: list[Tuple[MemoryState, float]] = []
    state = initial_state
    t = 0.0

    for outcome, gap in zip(outcomes, intervals):
        t += gap
        state, p = apply_review(state, t, outcome, theta)
        history.append((state, p))

    return history
