from __future__ import annotations

import datetime
from typing import Optional, List
from pydantic import BaseModel, Field

# Base schemas for Card data validation
class CardBase(BaseModel):
    content: str
    difficulty: Optional[int] = Field(5, ge=1, le=10)
    half_life: Optional[float] = Field(1.0, gt=0)

class CardCreate(CardBase):
    pass

class CardUpdate(BaseModel):
    difficulty: Optional[int] = Field(None, ge=1, le=10)
    half_life: Optional[float] = Field(None, gt=0)
    last_review: Optional[datetime.datetime] = None
    next_review: Optional[datetime.datetime] = None
    review_count: Optional[int] = None

class CardRead(CardBase):
    id: int
    last_review: datetime.datetime
    next_review: datetime.datetime
    review_count: int
    status: str  # 'active' | 'mastered'

    class Config:
        from_attributes = True


class TodayReviewItem(CardRead):
    """
    Richer response shape for GET /api/review/today.

    Extends CardRead with two fields that are computed at query time
    and never stored in the database:

    p_recall   — current recall probability P = 2^(−Δt / H).
                 A lower value means the memory has decayed more.
                 Useful for the frontend to show urgency colouring.

    is_overdue — True when next_review is already in the past,
                 meaning the user missed the optimal review window.
    """
    p_recall: float   = Field(..., ge=0.0, le=1.0,
                              description="Current recall probability [0,1]")
    is_overdue: bool  = Field(...,
                              description="True if next_review is before now")

# Schemas for Reviewing & Feedback
class ReviewExecution(BaseModel):
    card_id: int
    recalled: bool  # True for success, False for fail
    review_time: datetime.datetime = Field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc))

class ReviewResponse(BaseModel):
    p_value: float  # Estimated recall probability BEFORE review
    new_h: float    # Resulting half-life
    new_d: int      # Resulting difficulty
    delta_t: float  # Day since last review
    next_review: datetime.datetime

    class Config:
        from_attributes = True

# Log details (for analytics/V3)
class ReviewLogRead(BaseModel):
    id: int
    card_id: int
    review_time: datetime.datetime
    recalled: bool
    new_h: float
    new_d: int
    p_value: float

    class Config:
        from_attributes = True
