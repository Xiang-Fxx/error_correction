"""
Application configuration.

All tunable values are read from environment variables first,
with sensible development defaults as fallbacks.

Usage
-----
Set variables before launching the server:

  # Windows CMD
  set DATABASE_URL=sqlite+aiosqlite:///./ssp_mmc.db
  set SERVER_HOST=127.0.0.1
  set SERVER_PORT=8000
  python main.py

  # Or add them to a .env file and load with python-dotenv (optional).
"""

import os

# ── Database ──────────────────────────────────────────────────────────────
DATABASE_URL: str = os.environ.get(
    "DATABASE_URL",
    "sqlite+aiosqlite:///./ssp_mmc.db",
)

# ── Server ─────────────────────────────────────────────────────────────────
SERVER_HOST: str = os.environ.get("SERVER_HOST", "127.0.0.1")
SERVER_PORT: int = int(os.environ.get("SERVER_PORT", "8000"))

# ── SQLAlchemy ─────────────────────────────────────────────────────────────
# echo=True logs every SQL statement — useful for debugging, noisy in prod.
DB_ECHO: bool = os.environ.get("DB_ECHO", "false").lower() == "true"
