from __future__ import annotations

import datetime
from typing import Optional, List
from sqlalchemy import ForeignKey, String, Integer, Float, DateTime, func, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db import Base

class Card(Base):
    """
    Spaced Repetition Card Entity.
    Persistence for V1's MemoryState (D, H).
    """
    __tablename__ = "cards"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    content: Mapped[str] = mapped_column(String, index=True)
    difficulty: Mapped[int] = mapped_column(Integer, default=5)
    half_life: Mapped[float] = mapped_column(Float, default=1.0)
    last_review: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), 
        server_default=func.now()
    )
    next_review: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), 
        index=True
    )
    review_count: Mapped[int] = mapped_column(Integer, default=0)
    # 'active' = still learning; 'mastered' = user has marked as known
    status: Mapped[str] = mapped_column(
        String(16), default="active", server_default="active", index=True
    )

    # Relationships
    logs: Mapped[List[ReviewLog]] = relationship("ReviewLog", back_populates="card")

    def __repr__(self):
        return (f"<Card(id={self.id}, content='{self.content[:20]}...', "
                f"H={self.half_life:.2f}, next={self.next_review})>")

class ReviewLog(Base):
    """
    Historical log for V3 phase parameter fitting & analytics.
    """
    __tablename__ = "review_logs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    card_id: Mapped[int] = mapped_column(ForeignKey("cards.id"))
    
    review_time: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), 
        default=datetime.datetime.now(datetime.timezone.utc)
    )
    p_value: Mapped[float] = mapped_column(Float) # Recall probability at review
    recalled: Mapped[bool] = mapped_column()      # True=Succ, False=Fail
    delta_t: Mapped[float] = mapped_column(Float) # Inter-review interval (days)
    
    # State snapshots after review
    new_h: Mapped[float] = mapped_column(Float)
    new_d: Mapped[int] = mapped_column(Integer)

    # Relationships
    card: Mapped[Card] = relationship("Card", back_populates="logs")

    def __repr__(self):
        return (f"<ReviewLog(card_id={self.card_id}, "
                f"recalled={self.recalled}, p={self.p_value:.2f})>")
