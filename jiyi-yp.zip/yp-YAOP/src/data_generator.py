"""
Synthetic Data Generator — stdlib only (no numpy / pandas)
===========================================================
Generates realistic vocabulary review logs mirroring the KDD 2022
SSP-MMC paper, using only Python's built-in `random` and `math`.

Each record is a plain dict; the full dataset is a list of dicts.
"""

from __future__ import annotations

import csv
import logging
import math
import os
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

from dhp_model import (
    default_halflife,
    recall_prob_vec,
    clamp_halflife,
    H_MIN,
)
from state_transitions import halflife_on_success, halflife_on_failure, difficulty_update


# ---------------------------------------------------------------------------
# Ground-truth θ (what we try to recover by fitting)
# ---------------------------------------------------------------------------

TRUE_THETA: Dict[str, float] = {
    "theta1":  0.58,
    "theta2": -0.09,
    "theta3":  0.48,
    "theta4": -0.14,
    "theta5": -0.32,
    "theta6": -0.12,
}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class SimConfig:
    n_users:          int   = 200
    n_cards_per_user: int   = 50
    max_reviews:      int   = 20
    p_irregular:      float = 0.35
    irregular_scale:  float = 2.0
    noise_std:        float = 0.08
    seed:             int   = 42


# ---------------------------------------------------------------------------
# Generator — returns List[Dict]
# ---------------------------------------------------------------------------

def generate_dataset(cfg: SimConfig | None = None) -> List[Dict]:
    """
    Returns a list of review-event dicts with keys:
        user_id, card_id, difficulty, h_before, delta_t,
        recall_prob, outcome, h_after
    """
    if cfg is None:
        cfg = SimConfig()

    random.seed(cfg.seed)
    records: List[Dict] = []

    for user_id in range(cfg.n_users):
        # Per-user memory coefficient — adds realistic heterogeneity
        user_factor = random.gauss(1.0, 0.15)
        user_factor = max(0.5, min(2.0, user_factor))

        for card_id in range(cfg.n_cards_per_user):
            # Difficulty ~ N(6, 2) clipped to [1, 10]
            d = int(round(max(1.0, min(10.0, random.gauss(6.0, 2.0)))))

            h = default_halflife(d) * user_factor
            t = 0.0
            n_reviews = random.randint(3, cfg.max_reviews)

            for _ in range(n_reviews):
                opt_gap = -h * math.log2(0.90)

                if random.random() < cfg.p_irregular:
                    gap = opt_gap * random.uniform(0.3, cfg.irregular_scale)
                else:
                    gap = opt_gap * random.uniform(0.9, 1.1)

                gap = max(0.1, gap)
                t  += gap

                p        = recall_prob_vec(gap, h)
                recalled = 1 if random.random() < p else 0

                if recalled == 1:
                    h_new = halflife_on_success(
                        h=h, d=d, p=p,
                        theta1=TRUE_THETA["theta1"],
                        theta2=TRUE_THETA["theta2"],
                        theta3=TRUE_THETA["theta3"],
                        theta4=TRUE_THETA["theta4"],
                    )
                else:
                    h_new = halflife_on_failure(
                        h=h, d=d,
                        theta5=TRUE_THETA["theta5"],
                        theta6=TRUE_THETA["theta6"],
                    )

                noise = random.gauss(0.0, cfg.noise_std)
                h_new = clamp_halflife(h_new * math.exp(noise))

                records.append({
                    "user_id":     user_id,
                    "card_id":     card_id,
                    "difficulty":  d,
                    "h_before":    h,
                    "delta_t":     gap,
                    "recall_prob": p,
                    "outcome":     recalled,
                    "h_after":     h_new,
                })

                h = h_new
                d = difficulty_update(d, recalled)

    return records


# ---------------------------------------------------------------------------
# Summary printer
# ---------------------------------------------------------------------------

def summarise(records: List[Dict]) -> None:
    n      = len(records)
    n_ok   = sum(r["outcome"] for r in records)
    users  = len({r["user_id"] for r in records})
    cards  = len({r["card_id"] for r in records})
    avg_dt = sum(r["delta_t"] for r in records) / n
    min_h  = min(r["h_before"] for r in records)
    max_h  = max(r["h_before"] for r in records)

    d_counts: Dict[int, int] = {}
    for r in records:
        d_counts[r["difficulty"]] = d_counts.get(r["difficulty"], 0) + 1

    logger.info("=" * 60)
    logger.info("  Synthetic Dataset Summary")
    logger.info("=" * 60)
    logger.info("  Total review events : %d", n)
    logger.info("  Unique users        : %d", users)
    logger.info("  Unique cards/user   : %d", cards)
    logger.info("  Overall recall rate : %.1f%%", n_ok / n * 100)
    logger.info("  Avg dt (days)       : %.2f", avg_dt)
    logger.info("  H_before range      : [%.3f, %.1f]", min_h, max_h)
    logger.info("  Difficulty dist     :")
    for dv in sorted(d_counts):
        cnt = d_counts[dv]
        logger.info("    D=%2d: %d (%.1f%%)", dv, cnt, cnt / n * 100)
    logger.info("=" * 60)


# ---------------------------------------------------------------------------
# Train/test split
# ---------------------------------------------------------------------------

def train_test_split(
    records: List[Dict],
    train_frac: float = 0.8,
    seed: int = 0,
) -> Tuple[List[Dict], List[Dict]]:
    data = records[:]
    random.seed(seed)
    random.shuffle(data)
    cut = int(len(data) * train_frac)
    return data[:cut], data[cut:]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cfg  = SimConfig(n_users=200, n_cards_per_user=50, seed=42)
    data = generate_dataset(cfg)
    summarise(data)

    os.makedirs("data", exist_ok=True)
    with open("data/synthetic_reviews.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0].keys()))
        writer.writeheader()
        writer.writerows(data)
    logger.info("  Saved to data/synthetic_reviews.csv")
