import datetime
import os as _os
from contextlib import asynccontextmanager
from typing import List, Any

from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from db import engine, Base, get_db
from models import Card, ReviewLog
from config import SERVER_HOST, SERVER_PORT
from schemas import (
    CardCreate, CardRead, ReviewExecution, ReviewResponse, ReviewLogRead,
    TodayReviewItem,
)
from scheduler import (
    update_card_after_review,
    calculate_priority_score,
    TARGET_P
)
from dhp_model import recall_prob_vec

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Architectural Lifecycle:
    Ensures DB tables exist on startup and handles async clean-up.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield

app = FastAPI(
    title="SSP-MMC Memory Backend (V2)",
    description=(
        "Advanced Spaced Repetition Backend implementing the DHP Model "
        "(KDD 2022). Optimizes memory consolidation using 'Necessary Difficulty'."
    ),
    version="2.1.0",
    lifespan=lifespan
)

_static_dir = _os.path.join(_os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=_static_dir), name="static")

@app.get("/review", response_class=FileResponse, tags=["frontend"])
async def review_page():
    """Serves the today's-review frontend page."""
    return FileResponse(_os.path.join(_static_dir, "review.html"))

@app.get("/health", tags=["system"])
async def health_check():
    return {"status": "operational", "engine": "DHP-V2", "target_p": TARGET_P}

# --- Inventory Operations ---

@app.post("/cards/", response_model=CardRead, status_code=status.HTTP_201_CREATED, tags=["inventory"])
async def create_card(card_in: CardCreate, db: AsyncSession = Depends(get_db)):
    """
    Adds a new card to the memory vault.
    Initializes DHP parameters (D, H) for starting the learning curve.
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    new_card = Card(
        content=card_in.content,
        difficulty=card_in.difficulty,
        half_life=card_in.half_life,
        last_review=now,
        next_review=now,  # Due immediately for first study
        review_count=0
    )
    db.add(new_card)
    try:
        await db.commit()
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Persistence Error: {str(e)}")
    
    await db.refresh(new_card)
    return new_card

@app.get("/cards/", response_model=List[CardRead], tags=["inventory"])
async def get_all_cards(skip: int = 0, limit: int = 100, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Card).offset(skip).limit(limit))
    return result.scalars().all()

# --- Advanced Scheduling API ---

@app.get("/review/next/", response_model=List[CardRead], tags=["scheduler"])
async def get_priority_queue(
    limit: int = Query(10, gt=0), 
    db: AsyncSession = Depends(get_db)
):
    """
    THE SCHEDULER: Uses DHP-logic to return optimal cards.
    
    Strategy:
    1.  Filters for cards where next_review <= now.
    2.  Sorts by 'Priority Score' which peaks at P=0.618.
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    
    # Fetch due cards (over-fetching slightly to allow Python-side priority sorting)
    # Exclude mastered cards — they should never re-enter the queue.
    stmt = (
        select(Card)
        .where(Card.status == "active")
        .where(Card.next_review <= now)
        .limit(limit * 3)
    )
    result = await db.execute(stmt)
    candidates = result.scalars().all()
    
    # Sort by the architecturally-defined Priority Score
    # Higher score = more important review for memory efficiency.
    sorted_queue = sorted(
        candidates, 
        key=lambda c: calculate_priority_score(c), 
        reverse=True
    )
    
    return sorted_queue[:limit]

@app.post("/review/execute/", response_model=ReviewResponse, tags=["scheduler"])
async def record_review(
    review: ReviewExecution, 
    db: AsyncSession = Depends(get_db)
) -> Any:
    """
    Commits a review result to the brain.
    Triggers the DHP State Transition and updates the persistence layer.
    """
    # 1. Read
    stmt = select(Card).where(Card.id == review.card_id)
    result = await db.execute(stmt)
    card = result.scalar_one_or_none()
    
    if not card:
        raise HTTPException(status_code=404, detail="Card entity not found.")

    # 2. Transform (DHP Physics)
    # The scheduler handles the math for half-life growth/penalty
    outcome = await update_card_after_review(card, review.recalled, review.review_time)
    
    # 3. Log (Analytics for V3)
    log = ReviewLog(
        card_id=card.id,
        review_time=review.review_time,
        p_value=outcome["p_value"],
        recalled=review.recalled,
        delta_t=outcome["delta_t"],
        new_h=outcome["new_h"],
        new_d=outcome["new_d"]
    )
    db.add(log)
    
    # 4. Save
    try:
        await db.commit()
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail="Failed to persist review state.")
    
    return outcome

# --- Today's Review Queue ---

@app.get("/api/review/today", response_model=List[TodayReviewItem], tags=["review"])
async def get_today_review(db: AsyncSession = Depends(get_db)):
    """
    Returns all active cards whose next_review falls on or before the end of
    today (UTC). Cards with status='mastered' are excluded.

    Filter logic
    ------------
    - status == 'active'
    - next_review <= YYYY-MM-DD 23:59:59.999999 UTC  (today)

    Each item includes two computed fields that are NOT stored in the DB:
    - p_recall   : current recall probability P = 2^(-Δt / H)
    - is_overdue : True when next_review is already in the past
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    end_of_today = now.replace(hour=23, minute=59, second=59, microsecond=999999)

    stmt = (
        select(Card)
        .where(Card.status == "active")
        .where(Card.next_review <= end_of_today)
        .order_by(Card.next_review.asc())
    )
    result = await db.execute(stmt)
    cards = result.scalars().all()

    items: List[TodayReviewItem] = []
    for card in cards:
        # Compute delta_t safely (guard naive datetimes from SQLite)
        last = card.last_review
        if last.tzinfo is None:
            last = last.replace(tzinfo=datetime.timezone.utc)
        delta_t_days = max(0.0, (now - last).total_seconds() / 86400)

        p_recall   = recall_prob_vec(delta_t_days, card.half_life)
        # Guard next_review against naive datetimes from SQLite
        nr = card.next_review
        if nr.tzinfo is None:
            nr = nr.replace(tzinfo=datetime.timezone.utc)
        is_overdue = nr < now

        items.append(TodayReviewItem(
            # --- CardRead fields ---
            id           = card.id,
            content      = card.content,
            difficulty   = card.difficulty,
            half_life    = card.half_life,
            last_review  = card.last_review,
            next_review  = card.next_review,
            review_count = card.review_count,
            status       = card.status,
            # --- computed fields ---
            p_recall     = round(p_recall, 4),
            is_overdue   = is_overdue,
        ))

    return items


@app.post("/api/review/{card_id}/master", response_model=CardRead, tags=["review"])
async def mark_card_mastered(card_id: int, db: AsyncSession = Depends(get_db)):
    """
    Marks a card as 'mastered'. Mastered cards are excluded from future
    review queues.

    This endpoint is called when the user taps the '已掌握' button on the
    review page.
    """
    stmt = select(Card).where(Card.id == card_id)
    result = await db.execute(stmt)
    card = result.scalar_one_or_none()

    if not card:
        raise HTTPException(status_code=404, detail="Card not found.")

    card.status = "mastered"
    try:
        await db.commit()
    except Exception as e:
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Persistence error: {str(e)}")

    await db.refresh(card)
    return card


# --- Analytics ---

@app.get("/logs/{card_id}", response_model=List[ReviewLogRead])
async def get_card_logs(card_id: int, db: AsyncSession = Depends(get_db)):
    """
    Get full history of a card.
    """
    result = await db.execute(
        select(ReviewLog).where(ReviewLog.card_id == card_id).order_by(ReviewLog.review_time)
    )
    return result.scalars().all()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=SERVER_HOST, port=SERVER_PORT)

